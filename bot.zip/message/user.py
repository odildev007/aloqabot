from aiogram import Bot
from aiogram.types import Message
from aiogram.utils.chat_action import ChatActionSender
from asyncio import sleep
import asyncio

async def command_start_answer(message: Message, bot: Bot):
    async with ChatActionSender.typing(message.from_user.id, bot):
        await sleep(3)
        await message.answer("Assalomu alaykum")

async def echo(message: Message, bot: Bot):
    async with ChatActionSender.typing(message.from_user.id, bot):
        await sleep(3)
        await message.forward(chat_id=5165396993)
        await message.answer("✅ Xabaringiz yetkazildi! Iltimos kuting.")



