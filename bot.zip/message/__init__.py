from aiogram import Router, F
from aiogram.filters import CommandStart
from . import user
from . import admin


router = Router()
router.message.register(user.command_start_answer, CommandStart())
router.message.register(user.echo, F.from_user.id != 5165396993)
router.message.register(admin.admin_message)
