from aiogram import Bot
from aiogram.types import Message
from aiogram.utils.chat_action import ChatActionSender


async def admin_message(message: Message, bot: Bot):
    if message.reply_to_message:
        await message.copy_to(chat_id=message.reply_to_message.forward_from.id)
        await message.answer("✅ Xabaringiz yuborildi!")
    else:
        await message.answer("Kimgadir yozmoqchi bo'lsangiz uni xabariga reply qiling.")
