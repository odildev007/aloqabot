from aiogram import Bot, Dispatcher, F, flags
from asyncio import run
import message

dp = Dispatcher()

async def startup_answer(bot: Bot):
    await bot.send_message(5165396993, "Bot ishga tushdi! ✅")

async def shutdown_answer(bot: Bot):
    await bot.send_message(5165396993, "Bot ishdan to'xtadi! ❗")

async def start():
    dp.startup.register(startup_answer)
    dp.shutdown.register(shutdown_answer)

    dp.include_router(message.router)
    bot = Bot("6923568104:AAE-x28zkaHDSQ7TZouvZGxfve979rKTqC4", parse_mode="HTML")

    await dp.start_polling(bot, polling_timeout=1)


run(start())